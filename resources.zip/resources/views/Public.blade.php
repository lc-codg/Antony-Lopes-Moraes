@extends('Base')

@section('content')

@endsection
<style>
    body, html {
  height: 100%;
  width: 100%;
  
  
}

body{
  /* The image used */
  background-image: url('img/empresa.jpg');


  /* Full height */
  height: 50%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
