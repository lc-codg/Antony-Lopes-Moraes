<style>
    .footer {

        bottom: 0;
        width: 100%;
        background-color: black;
        color: white;
        text-align: center;
        position:FIXED;

    }
</style>


<br><br><br>

<div class="footer">
    <p style='color:white;font-size:15px;'>© 2022 por Antony Lopes Desenvolvimento de Sistemas. Contato: (21)98837-3398</P>
</div>
